# IssueTracker
Django Based Website For Tracking Issues In The System/Framework.

Python 3.6 Django 2 With Authentication and No Sql Database [DBlite].

Tracks Issues From Any Workflow, OpenSource/Free.

Can be use in Automotive or Banking Field easily.

Easy to undestand and support multiple allowed host.

It can be accessible in multiple local network too. 

Dyanamic graphs and very handy search engine.
