from django.apps import AppConfig


class IssueUpdaterConfig(AppConfig):
    name = 'issue_updater'
